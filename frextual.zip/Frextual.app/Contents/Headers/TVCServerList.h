/* ********************************************************************* 
       _____        _               _    ___ ____   ____
      |_   _|___  _| |_ _   _  __ _| |  |_ _|  _ \ / ___|
       | |/ _ \ \/ / __| | | |/ _` | |   | || |_) | |
       | |  __/>  <| |_| |_| | (_| | |   | ||  _ <| |___
       |_|\___/_/\_\\__|\__,_|\__,_|_|  |___|_| \_\\____|

 Copyright (c) 2010 — 2012 Codeux Software & respective contributors.
        Please see Contributors.pdf and Acknowledgements.pdf

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the Frextual IRC Client & Codeux Software nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 *********************************************************************** */

#import "TextualApplication.h"

@interface TVCServerList : NSOutlineView
@property (nonatomic, unsafe_unretained) id keyDelegate;
@property (nonatomic, strong) NSImage *defaultDisclosureTriangle;
@property (nonatomic, strong) NSImage *alternateDisclosureTriangle;
@property (nonatomic, assign) NSInteger layoutIconSpacing;
@property (nonatomic, assign) NSInteger layoutBadgeHeight;
@property (nonatomic, assign) NSInteger layoutBadgeRightMargin;
@property (nonatomic, assign) NSInteger layoutBadgeInsideMargin;
@property (nonatomic, assign) NSInteger layoutBadgeMinimumWidth;
@property (nonatomic, strong) NSFont *layoutBadgeFont;
@property (nonatomic, strong) NSFont *layoutServerCellFont;
@property (nonatomic, strong) NSFont *layoutChannelCellFont;
@property (nonatomic, strong) NSFont *layoutChannelCellSelectionFont;
@property (nonatomic, strong) NSColor *layoutBadgeTextColorNS;
@property (nonatomic, strong) NSColor *layoutBadgeTextColorTS;
@property (nonatomic, strong) NSColor *layoutBadgeShadowColor;
@property (nonatomic, strong) NSColor *layoutBadgeHighlightBackgroundColor;
@property (nonatomic, strong) NSColor *layoutBadgeMessageBackgroundColorAqua;
@property (nonatomic, strong) NSColor *layoutBadgeMessageBackgroundColorGraphite;
@property (nonatomic, strong) NSColor *layoutBadgeMessageBackgroundColorTS;
@property (nonatomic, strong) NSColor *layoutServerCellFontColor;
@property (nonatomic, strong) NSColor *layoutServerCellFontColorDisabled;
@property (nonatomic, strong) NSColor *layoutServerCellSelectionFontColor_AW;
@property (nonatomic, strong) NSColor *layoutServerCellSelectionFontColor_IA;
@property (nonatomic, strong) NSColor *layoutServerCellSelectionShadowColorAW;
@property (nonatomic, strong) NSColor *layoutServerCellSelectionShadowColorIA;
@property (nonatomic, strong) NSColor *layoutServerCellShadowColorAW;
@property (nonatomic, strong) NSColor *layoutServerCellShadowColorNA;
@property (nonatomic, strong) NSColor *layoutChannelCellFontColor;
@property (nonatomic, strong) NSColor *layoutChannelCellSelectionFontColor_AW;
@property (nonatomic, strong) NSColor *layoutChannelCellSelectionFontColor_IA;
@property (nonatomic, strong) NSColor *layoutChannelCellShadowColor;
@property (nonatomic, strong) NSColor *layoutChannelCellSelectionShadowColor_AW;
@property (nonatomic, strong) NSColor *layoutChannelCellSelectionShadowColor_IA;
@property (nonatomic, strong) NSColor *layoutGraphiteSelectionColorAW;

- (NSImage *)disclosureTriangleInContext:(BOOL)up selected:(BOOL)selected;

- (void)updateBackgroundColor;
- (void)toggleAddServerButton;
@end

@interface NSObject (ServerListDelegate)
- (void)serverListKeyDown:(NSEvent *)e;
@end